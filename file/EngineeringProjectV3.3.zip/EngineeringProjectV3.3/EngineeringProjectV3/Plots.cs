﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineeringProjectV3
{
    class Plots
    {
        public static void PlotOne(double Ya, double z1)
        {
            // 0 <= z1 <= 0.25(0 - F1)
            BeamCalculation.VLateralForce = (-1) * Ya;
            BeamCalculation.VBendingMoment = (-1) * Ya * z1;
        }
        public static void PlotTwo(double Ya, double z2)
        {
            // 0 <= z2 <= 0.05(F1 - q)
            BeamCalculation.VLateralForce = BeamCalculation.VPowerOne - Ya;
            BeamCalculation.VBendingMoment = (BeamCalculation.VPowerOne * z2) - (Ya * (z2 + BeamCalculation.VForceOneLength));
        }
        public static void PlotThree(double Ya, double z3)
        {
            // 0 <= z3 <= 0.3(q1 - q2)
            double z2 = BeamCalculation.VDistributedStartLength - BeamCalculation.VForceOneLength;
            BeamCalculation.VLateralForce = ((-1) * BeamCalculation.VDistributedLoad * z3) + BeamCalculation.VPowerOne - Ya;
            BeamCalculation.VBendingMoment = ((-1) * (BeamCalculation.VDistributedLoad * Math.Pow(z3, 2) / 2)) + (BeamCalculation.VPowerOne * (z3 + z2)) - (Ya * (z3 + BeamCalculation.VDistributedStartLength));
        }
        public static void PlotFour(double Yb, double z4)
        {
            // 0 <= z4 <= 0.2(F2 - l)
            BeamCalculation.VLateralForce = Yb;
            BeamCalculation.VBendingMoment = (-1) * Yb * z4;
        }
        public static void PlotFive(double Yb, double z5)
        {
            // 0 <= z4 <= 0.2(q2 - F2)
            BeamCalculation.VLateralForce = ((-1) * BeamCalculation.VPowerTwo) + Yb;
            BeamCalculation.VBendingMoment = (BeamCalculation.VPowerTwo * z5) - (Yb * (z5 + (BeamCalculation.VForceTwoLength - BeamCalculation.VDistributedEndLength)));
        }
    }
}
