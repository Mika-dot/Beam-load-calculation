﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EngineeringProjectV3
{
    class Support
    {
        public static double OneStageFastening()
        {
            // Фактически расчет момента относительно ya (для нахождения yb).
            return ((BeamCalculation.VPowerOne * BeamCalculation.VForceOneLength) + (BeamCalculation.VPowerTwo * BeamCalculation.VForceTwoLength) - (BeamCalculation.VDistributedLoad * BeamCalculation.VDistributedStartLength * (BeamCalculation.VDistributedStartLength + ((BeamCalculation.VDistributedEndLength - BeamCalculation.VDistributedStartLength) / 2)))) / BeamCalculation.VLength;
        }
        public static double TwoDegreeFastening(double OneStageFastening)
        {
            // Фактически расчет силы при известном ya (для нахождения ya).
            return BeamCalculation.VPowerOne + BeamCalculation.VPowerTwo - (BeamCalculation.VDistributedLoad * (BeamCalculation.VDistributedEndLength - BeamCalculation.VDistributedStartLength)) - OneStageFastening;
        }
    }
}
